﻿using SAP.Middleware.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace OTSapi.Services
{
    public class SapServices
    {
        public RfcConfigParameters GetParameters()
        {
            RfcConfigParameters parms = new RfcConfigParameters();
            parms.Add(RfcConfigParameters.Name, "QA");

            parms.Add(RfcConfigParameters.AppServerHost, ConfigurationManager.AppSettings["AppServer"]);// 
            parms.Add(RfcConfigParameters.SystemNumber, ConfigurationManager.AppSettings["SystemNumber"]);//
            parms.Add(RfcConfigParameters.SystemID, ConfigurationManager.AppSettings["SystemID"]);//
            parms.Add(RfcConfigParameters.User, ConfigurationManager.AppSettings["User"]);//
            parms.Add(RfcConfigParameters.Password, ConfigurationManager.AppSettings["Password"]);//
            parms.Add(RfcConfigParameters.Client, ConfigurationManager.AppSettings["Client"]);
            parms.Add(RfcConfigParameters.Language, "EN");//
            return parms;
        }
        public static List<T> ConvertToList<T>(DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName.ToLower()).ToList();
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name.ToLower()))
                    {
                        try
                        {
                            pro.SetValue(objT, row[pro.Name]);
                        }
                        catch (Exception ex) { }
                    }
                }
                return objT;
            }).ToList();
        }

            public List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        public T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
        public DataTable convertToDotnetTable(IRfcTable RFCTable)
        {
            DataTable dt = new DataTable();

            for (int item = 0; item < RFCTable.ElementCount; item++)
            {
                RfcElementMetadata metadata = RFCTable.GetElementMetadata(item);
                dt.Columns.Add(metadata.Name);

            }

            foreach (IRfcStructure row in RFCTable)
            {
                DataRow dr = dt.NewRow();
                for (int item = 0; item < RFCTable.ElementCount; item++)
                {
                    RfcElementMetadata metadata = RFCTable.GetElementMetadata(item);
                    if (metadata.DataType == RfcDataType.BCD && metadata.Name == "ABC")
                    {
                        dr[item] = row.GetInt(metadata.Name);
                    }
                    else
                    {
                        dr[item] = row.GetString(metadata.Name);
                    }

                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
        
    }
}