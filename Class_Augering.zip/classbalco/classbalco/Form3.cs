﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace classbalco
{
    public partial class Form3 : Form
    {
        private bool isIcon1 = true;
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label68_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if(isIcon1)
            {
                pictureBox3.Image = Image.FromFile("C:\\Users\\CG-DTE\\Downloads\\Chk.png");
                label11.Text = "yes";
            }
            else
            {
                pictureBox3.Image = Image.FromFile("C:\\Users\\CG-DTE\\Downloads\\Uchk.png");
                label11.Text = "no";
            }

            isIcon1 = !isIcon1;
        }
    }
}
