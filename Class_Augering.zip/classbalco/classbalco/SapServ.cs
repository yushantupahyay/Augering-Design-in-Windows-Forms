using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace classbalco
{

    public List<T> ConvertDataTable<T>(DataTable dt)
    {
        List<T> data = new List<T>();
        foreach (DataRow row in dt.Rows)
        {
            T item = GetItem<T>(row);
            data.Add(item);
        }
        return data;
    }
    public T GetItem<T>(DataRow dr)
    {
        Type temp = typeof(T);
        T obj = Activator.CreateInstance<T>();

        foreach (DataColumn column in dr.Table.Columns)
        {
            foreach (PropertyInfo pro in temp.GetProperties())
            {
                if (pro.Name == column.ColumnName)
                    pro.SetValue(obj, dr[column.ColumnName], null);
                else
                    continue;
            }
        }
        return obj;
    }
    //public DataTable ConvertToDotnetTable(IRfcTable RFCTable)
    //{
    //    DataTable dt = new DataTable();

    //    for (int item = 0; item < RFCTable.ElementCount; item++)
    //    {
    //        RfcElementMetadata metadata = RFCTable.GetElementMetadata(item);
    //        dt.Columns.Add(metadata.Name);

    //    }

    //    foreach (IRfcStructure row in RFCTable)
    //    {
    //        DataRow dr = dt.NewRow();
    //        for (int item = 0; item < RFCTable.ElementCount; item++)
    //        {
    //            RfcElementMetadata metadata = RFCTable.GetElementMetadata(item);
    //            if (metadata.DataType == RfcDataType.BCD && metadata.Name == "ABC")
    //            {
    //                dr[item] = row.GetInt(metadata.Name);
    //            }
    //            else
    //            {
    //                dr[item] = row.GetString(metadata.Name);
    //            }
    //        }
    //        dt.Rows.Add(dr);
    //    }
    //    return dt;
    //}
    public RfcConfigParameters GetParameters()
    {
        RfcConfigParameters parms = new RfcConfigParameters();
        parms.Add(RfcConfigParameters.Name, "QA");
        parms.Add(RfcConfigParameters.AppServerHost, ConfigurationManager.AppSettings.Get("AppServer"));// 
        parms.Add(RfcConfigParameters.SystemNumber, ConfigurationManager.AppSettings.Get("SystemNumber"));//            
        parms.Add(RfcConfigParameters.SystemID, ConfigurationManager.AppSettings.Get("SystemID"));//
        parms.Add(RfcConfigParameters.User, ConfigurationManager.AppSettings.Get("User"));//
        parms.Add(RfcConfigParameters.Password, ConfigurationManager.AppSettings.Get("Password"));//
        parms.Add(RfcConfigParameters.Client, ConfigurationManager.AppSettings.Get("Client"));
        //parms.Add(RfcConfigParameters.SAPRouter, ConfigurationManager.AppSettings.Get("SapRouter"));
        parms.Add(RfcConfigParameters.Language, "EN");//
        return parms;
    }
    //Service to Authorise the login 
    public string LoginBapi(string TRANS_NAME, string PASSWORD)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        ////RfcSessionManager.BeginContext(rfc);
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZBAPI_ICTMS_LOGIN");
        IRfcTable QTAB = funcCust.GetTable("IT_RETURN");
        funcCust.SetValue("P_USERID", TRANS_NAME);
        funcCust.SetValue("P_PASSWORD", PASSWORD);
        funcCust.Invoke(rfc);
        string msg = QTAB.GetValue("MESSAGE").ToString();
        return msg;
    }
    //Service to get Role based on userid
    public DataTable GetroleUser(string P_TRANSID)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        ////RfcSessionManager.BeginContext(rfc);
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZBAPI_ICTMS_LOGIN");
        IRfcTable QTABVH = funcCust.GetTable("IT_TAB");

        funcCust.SetValue("P_USERID", P_TRANSID);
        //funcCust.SetValue("P_REGNO", P_REGNO);
        funcCust.Invoke(rfc);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        ds.Tables.Add(convertToDotnetTable(QTABVH));
        dt = ds.Tables[0];
        ////RfcSessionManager.EndContext(rfc);
        return dt;
    }
    //based on auger get latest auger history
    public DataTable getAurgerLatest(string AUGER_NAME)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        ////RfcSessionManager.BeginContext(rfc);
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZCLASS_AUGER_LAST_TRANS");
        IRfcTable QTAB = funcCust.GetTable("IT_GET");
        funcCust.SetValue("AUGER_NAME", AUGER_NAME);
        funcCust.Invoke(rfc);
        DataTable dt;
        dt = convertToDotnetTable(QTAB);
        return dt;
    }
    //based on rfids get vehicle data
    public DataSet BinAssignGet3tagreading2_0(List<string> L_RFID)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        //RfcSessionManager.BeginContext(rfc);
        //IRfcFunction funcCust = rfc.Repository.CreateFunction("ZICTMS_BIN_ASSIGN3_UNLOAD");
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZICTMS_BIN_ASSIGN");
        IRfcTable QTAB = funcCust.GetTable("T_RFID");
        IRfcTable QTABRFID = funcCust.GetTable("RFID_POST");
        IRfcTable RETURN = funcCust.GetTable("RETURN");
        foreach (string rfid in L_RFID)
        {
            QTABRFID.Append();
            QTABRFID.SetValue("RFID", rfid);
        }
        //funcCust.SetValue("L_RFID", L_RFID);
        funcCust.SetValue("OPTYPE", "S");
        funcCust.Invoke(rfc);
        DataSet ds = new DataSet();
        string msg = funcCust.GetValue("RET_MSG").ToString();
        string msg1 = funcCust.GetValue("RET_MSG1").ToString();
        DataTable dt = new DataTable("tablemsg");
        string agrmsg = RETURN.GetValue("MESSAGE").ToString();
        dt.Columns.Add("message");
        dt.Rows.Add(msg);
        dt.Rows.Add(msg1);
        dt.Rows.Add(agrmsg);
        ds.Tables.Add(convertToDotnetTable(QTAB));
        ds.Tables.Add(dt);
        //RfcSessionManager.EndContext(rfc);

        return ds;
    }
    //get vehicle status
    public DataTable getVehStatusExit(string P_GATEPASS)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        //RfcSessionManager.BeginContext(rfc);
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZICTMS_VEHICLE_GATE_EXIT");
        IRfcTable QTAB = funcCust.GetTable("IT_STATS");
        funcCust.SetValue("P_GATEPASS", P_GATEPASS);
        funcCust.Invoke(rfc);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        ds.Tables.Add(convertToDotnetTable(QTAB));
        dt = ds.Tables[0];
        //RfcSessionManager.EndContext(rfc);
        return dt;
    }
    //post suger data and get response
    public string BinAssignPost3Manual2_0(string L_RFID, DataTable dt, string REMARKS)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        //RfcSessionManager.BeginContext(rfc);
        //IRfcFunction funcCust = rfc.Repository.CreateFunction("ZICTMS_BIN_ASSIGN");
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZICTMS_BIN_ASSIGN");
        IRfcTable QTAB = funcCust.GetTable("T_RFID");
        IRfcTable QTAB2 = funcCust.GetTable("RETURN");
        funcCust.SetValue("L_RFID", L_RFID);
        funcCust.SetValue("OPTYPE", "A");
        funcCust.SetValue("MANUAL", "X");
        foreach (DataRow dr in dt.Rows)
        {
            QTAB.Append();
            QTAB.SetValue("VCLREG_NO", dr["VCLREG_NO"].ToString());
            QTAB.SetValue("GATEPASSNO", dr["GATEPASSNO"].ToString());
            QTAB.SetValue("PLANT", dr["PLANT"].ToString());
            QTAB.SetValue("WGTSTAT", dr["WGTSTAT"].ToString());
            QTAB.SetValue("AVG_WT", dr["AVG_WT"].ToString());
            QTAB.SetValue("UNLOADED_FLG", dr["UNLOADED_FLG"].ToString());
            QTAB.SetValue("B_TOLERANCE", dr["B_TOLERANCE"].ToString());
            QTAB.SetValue("VEHICLETYPE", dr["VEHICLETYPE"].ToString());
            QTAB.SetValue("PRODUCTTYPE", dr["PRODUCTTYPE"].ToString());
            QTAB.SetValue("DRIVERNAME", dr["DRIVERNAME"].ToString());
            QTAB.SetValue("RFID", dr["RFID"].ToString());
            QTAB.SetValue("CHALLAN_GROSS", dr["CHALLAN_GROSS"].ToString());
            QTAB.SetValue("CHALLAN_TARE", dr["CHALLAN_TARE"].ToString());
            QTAB.SetValue("BINNO", dr["BINNO"].ToString());
            QTAB.SetValue("SPCL_SMPL", dr["SPCL_SMPL"].ToString());
            QTAB.SetValue("SAMPLEID", dr["SAMPLEID"].ToString());
            QTAB.SetValue("UNLOADLOC", dr["UNLOADLOC"].ToString());
            QTAB.SetValue("SMPL_AREA", dr["SMPL_AREA"].ToString());
            QTAB.SetValue("SMPL_POINT", dr["SMPL_POINT"].ToString());
            QTAB.SetValue("AUGUR_ID", dr["AUGUR_ID"].ToString());
            QTAB.SetValue("REMARKS", REMARKS);
        }

        funcCust.Invoke(rfc);
        string MSG = QTAB2.GetString("MESSAGE");
        //RfcSessionManager.EndContext(rfc);
        return MSG;

    }
    //against gp get auger response
    public string getAurgerAgainstGP(string GATEPASS)
    {
        RfcConfigParameters parms = GetParameters();
        RfcDestination rfc = RfcDestinationManager.GetDestination(parms);
        ////RfcSessionManager.BeginContext(rfc);
        IRfcFunction funcCust = rfc.Repository.CreateFunction("ZCLASS_AUGER_LAST_TRANS");
        IRfcTable QTAB = funcCust.GetTable("IT_RETURN");
        funcCust.SetValue("GATEPASS", GATEPASS);
        funcCust.Invoke(rfc);
        DataTable dt;
        string msg;
        msg = QTAB.GetString("MESSAGE");
        return msg;
    }
}
